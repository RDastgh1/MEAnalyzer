% General preferences and configuration information.
%
